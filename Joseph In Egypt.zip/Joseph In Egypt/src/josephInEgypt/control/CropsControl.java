/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package josephInEgypt.control;

//The CropsControl class
//Purpose: Create/store all methods related to crops
//Author: rbtwa (Rob Wagner)
//Last modified Date: 11/14/2017
//-------------------------------------------------------------
import java.util.Random;
import byui.cit260.josephInEgypt.model.Crops;
import byui.cit260.josephInEgypt.exceptions.CropExceptions;

public class CropsControl
{
    // random number generator
    static Random random = new Random();
    
    //Declare variables used
    private static final int LAND_BASE = 17;
    private static final int LAND_RANGE = 10;
    private static final int ACRES_PER_BUSHEL = 2;
    private static final int YIELD_BASE = 3;
    private static final int YIELD_RANGE = 3;
    private static final int PHARAOH_RANGE = 2;
    private static final int PHARAOH_BASE = 8;
    private static final double TO_PERCENT = 100.0;
    private static final int GROWTH_RANGE = 5;
    private static final int BUSHELS_PER_PERSON = 20;   
    private static final int PEOPLE_PER_ACRE = 9;
    
    //calcLandCost() method
    //Purpose: Calculate a random land cost between 17 and 26 bushels/acre
    //Parameters: none
    //Returns: land cost
    public static int calcLandCost()
    {
        int landPrice = random.nextInt(LAND_RANGE) + LAND_BASE;  
        return landPrice;            
    }

    
    //buyLand method - with exceptions
    //Purpose: Buy land - adds to acres owned
    //Parameters: The game object and the number of acres to buy
    //Pre-conditions: 0 < toBuy and wheatInStore > buy * landPrice
    //Post-conditions: 
    //Returns: none
    public static void buyLand(Crops theCrops, int toBuy, int landCost) throws CropExceptions
    {
        // check parameters - do they meet the contract
        if(toBuy < 0)
            throw new CropExceptions("A negative value was input");
        int wheat = theCrops.getWheatInStore();
        if(wheat < toBuy * landCost)
            throw new CropExceptions("There is insufficient wheat to buy this much land");

        // add the number of acres to buy to current number of acres
        int acresOwned = theCrops.getAcres();
        acresOwned += toBuy;
        theCrops.setAcres(acresOwned);
        
        // deduct cost from wheatInStore
        wheat = theCrops.getWheatInStore();
        wheat -= (toBuy * landCost);
        theCrops.setWheatInStore(wheat);
    }
    
    // sellLand method
    // Purpose: Sell land - deduct from acres owned
    // Parameters: The game object and the number of acres to buy
    // Pre-conditions: 0 < toSell and toSell < acres owned
    // Returns: none
    public static void sellLand(Crops theCrops, int toSell, int landCost) throws CropExceptions
    {
        // check for negative value
        if(toSell < 0)
            throw new CropExceptions("A negative value was input");
        
        // check for not enough land
        int acresOwned = theCrops.getAcres();       
        if(toSell > acresOwned)
            throw new CropExceptions("You do not have this much land.");
        
        // subtract the acres to sell from the current acres owned and store it
        acresOwned -= toSell;
        theCrops.setAcres(acresOwned);
        
        // add cost to wheatInStore
        int wheat = theCrops.getWheatInStore();
        wheat += (toSell * landCost);
        theCrops.setWheatInStore(wheat);
    }   
    
    // feedPeople method
    // Purpose: Feed the population
    // Parameters: The game object and the number of bushels to feed them
    // Pre-conditions: 0 < food and wheatInStore > food
    // Returns: none
    public static void feedPeople(Crops theCrops, int food) throws CropExceptions
    {
        // check parameters
        if(food < 0)
            throw new CropExceptions("A negative value was input.");
        
        int wheat = theCrops.getWheatInStore();       
        if(food > wheat)
            throw new CropExceptions("You do not have this much wheat in store.");
        
        // deduct food from wheatInStore
        wheat -= food;
        theCrops.setWheatInStore(wheat);
    }

    // plantCrops method
    // Purpose: plant wheat 
    // Parameters: The game object and the number of acres to plant
    // Pre-conditions: 0 < toPlant and wheatInStore > toPlane / 2
    // Returns: none
    public static void plantCrops(Crops theCrops, int toPlant) throws CropExceptions
    {
        // check parameters
        // input cannot be negative
        if(toPlant < 0)
            throw new CropExceptions("A negative value was entered.");
        
        // see if there is enough land to plant this many acres
        int acresOwned = theCrops.getAcres();
        if(acresOwned < toPlant)
            throw new CropExceptions("You do not own this much land.");
        
        // see if is enough seed to plant this many acres
        int wheat = theCrops.getWheatInStore();
        if((int)(toPlant / ACRES_PER_BUSHEL) > wheat)
            throw new CropExceptions("You do not have enough wheat to plant this much land.");
        
        // see if there are enough people to tend this many acres
        int population = theCrops.getPopulation();
        if(toPlant > (population * PEOPLE_PER_ACRE))
        {
            throw new CropExceptions("There are not enough people to tend this many acres.");
        }
        
        // set the number of acres planted
        theCrops.setPlanted(toPlant);
        
        // deduct cost from wheatInStore
        int temp = theCrops.getWheatInStore();
        temp -= (int)(toPlant / ACRES_PER_BUSHEL);
        theCrops.setWheatInStore(temp);
    }    
    
    // harvestCrops method
    // Purpose: harvest wheat 
    // Parameters: a reference to the game object 
    // Pre-conditions: none
    // Returns: none
    public static void harvestCrops(Crops theCrops)
    {
        // get random number for crop yield
        int yield = random.nextInt(YIELD_RANGE) + YIELD_BASE;
        //yield is between 3 and 6 bushels per acre
        theCrops.setCropYield(yield);
        
        // calculate amount of harvest and save it
        int harvest = theCrops.getPlanted() * yield;
        theCrops.setHarvest(harvest);
        
        // store the harvest
        int inStore = theCrops.getWheatInStore();
        inStore += harvest;
        theCrops.setWheatInStore(inStore);
    }   
    
    // payPharoh method
    // Purpose: Calculate how much wheat to give to Pharoh
    // Parameters: a reference to the Game object
    // Returns: none
    public static void payPharoh(Crops theCrops)
    {
        // get random number between 8% and 10%
        double off = (random.nextInt(PHARAOH_RANGE) + PHARAOH_BASE)/TO_PERCENT;
        int harvest = theCrops.getHarvest();
        int offering = (int)(harvest * off); 
        theCrops.setPharaohsShare(offering);
        
        // subtract offering from wheat in store
        int inStore = theCrops.getWheatInStore();
        inStore -= offering;
        theCrops.setWheatInStore(inStore);
    }
    
    // growPopulation method
    // Purpose: increase population by random percentage
    // Parameters: a reference to the Game object
    // Return: none
    public static void growPopulation(Crops theCrops)
    {
        int growthFactor = random.nextInt(GROWTH_RANGE) + 1;
        int land = theCrops.getAcres();
        int inStore = theCrops.getWheatInStore();
        int population = theCrops.getPopulation();
        
        // divide the wheat available by the population
        // multiply by a random number and convert to a percentage
        // this equation comes from the Hamurabi game
        int newPeople = (int)(growthFactor * (BUSHELS_PER_PERSON * land + inStore)
                /population/TO_PERCENT +1);
        theCrops.setNewPeople(newPeople);
    }
    
    // calcStarved method
    // Purpose: caculate the number of people who starved
    // Parameters: a reference to the Game object and the number of bushels
    // Pre-conditions: 0 < the number of bushels < bushels in Store
    // Returns: none
    public static void calcStarved(Crops theCrops, int bushelsToFeed)
    {
        // a person requires 20 bushels to survive
        // calculate the number of people who got fed
        int numberWhoDied = 0;
        int fed = bushelsToFeed / BUSHELS_PER_PERSON;
        theCrops.setFed(fed);
        int population = theCrops.getPopulation();
        if (population > fed)
        {
            numberWhoDied = population - fed;
            theCrops.setNumberWhoDied(numberWhoDied);                
        }
    }
}
    
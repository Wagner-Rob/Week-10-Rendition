
//Note: Referenced brother deBry's example for structure, and proper calling
//of methods, but aligned with our team's project/variables.

//Map Control class
//Purpose: Implement the Map (from the model layer) in a game session
//Author: Rob Wagner
//Date modified: 11.18.2017
package josephInEgypt.control;
import byui.cit260.josephInEgypt.model.*;

public class MapControl
{
    public static Map createMap()
    {
        //create the map object
        Map theMap = new Map(5,5);
        
        //return it to the calling method
        return theMap;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byui.cit260.josephInEgypt.view;

import java.util.Scanner;
import byui.cit260.joseph.in.egypt.JosephInEgypt;
import byui.cit260.josephInEgypt.model.*;
/**
 *
 * @author cameroncook
 * @co-author Rob Wagner
 */
public class GameMenuView 
{

    private static Game theGame = JosephInEgypt.getCurrentGame();
    private enum Choices {DISPLAY_MAP, MOVE_PLAYER, MANAGE_CROPS, QUIT};
    private final static int MAX=4;
    
    public GameMenuView() 
    {
    }
    
    public static void displayMap()
    {
        Game theGame = JosephInEgypt.getCurrentGame();
        Map theMap = theGame.getMap();
        int rows = theMap.getNumRows();
        int cols = theMap.getNumColumns();
        
        // display header
        System.out.println("\n\n\n\n\n     ***   VILLAGE MAP   ***");
        System.out.println("     1     2     3     4     5");
        
        // for each row in the map
        for(int i = 0; i < rows; i++)
        {
            // display the row number
            System.out.print(i+1 + " ");
            
            // for each column in the row
            for(int j = 0; j < cols; j++)
            {
                String symbol = theMap.getLocation(i,j).getSymbol();

                System.out.print("| " + symbol + " ");
            }
            System.out.println("|");
        }
        System.out.println("Key:");
        System.out.println("oOo - village");
        System.out.println("!!! - wheat");
        System.out.println("~~~ - River");
        System.out.println("... - desert");;
    }
    
    public void movePlayer()
    {
            Game theGame = JosephInEgypt.getCurrentGame();
            Player thePlayer = JosephInEgypt.getPlayer();
            Map theMap = theGame.getMap();
            
            System.out.println("Enter the coordinates of the location you want to move to.");
            int xcoord = getCoordinate("x-coordinate");
            thePlayer.setXCoordinate(xcoord-1);
            
            int ycoord = getCoordinate("y-coordinate");
            // getCoordinate return a number between 1 and 5, we need
            // a number between 0 and 4
            thePlayer.setYCoordinate(ycoord-1);
            Location location = theMap.getLocation(xcoord-1, ycoord-1);
            System.out.println(location.getDescription());
    }
    
    public static int getCoordinate(String which)
    {
        Scanner keyboard = new Scanner(System.in);
        int coord = 0;
        do
        {
            System.out.print("Enter the " + which + ": ");
            coord = keyboard.nextInt();
            if(coord < 1 || coord > MAX)
            {
                System.out.println("Invalid input: coordinate must be between 0 and " + MAX);
            }
        } while (coord < 1 || coord > MAX);
        return coord;
    }    
    
    
    
}

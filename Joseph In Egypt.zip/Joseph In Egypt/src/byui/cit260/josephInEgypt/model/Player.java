/*
*CIT260
*@author Rob Wagner
*Date modified: 11/18/2017
 */
package byui.cit260.josephInEgypt.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class Player implements Serializable
{
    private String playerName;
    private int xCoordinate;
    private int yCoordinate;
    
    //empty default constructor
    public Player()
    {
    }
    
    //setName method
    //Purpose: store the player's name
    //Parameters: The players name (string)
    //Returns: none
    public void setName(String _name)
    {
        playerName = _name;
    }
    
    //getName method
    //Purpose: Returns the name of the player
    //Parameters: none
    //Returns: the name of the player as a string
    public String getName()
    {
        return playerName;
    }
    
    public void setXCoordinate(int x)
    {
        xCoordinate = x;
    }
    
    public void setYCoordinate(int y)
    {
        yCoordinate = y;
    }
    
    public int getXCoordinate()
    {
        return xCoordinate;
    }
    
    public int getYCoordinate()
    {
        return yCoordinate;
    }
}

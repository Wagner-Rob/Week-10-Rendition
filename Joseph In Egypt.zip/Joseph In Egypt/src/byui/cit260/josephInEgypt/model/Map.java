/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byui.cit260.josephInEgypt.model;

/**
 *
 * @author rbtwa
 */

import java.io.Serializable;


public class Map
{

//The Map class
//Purpose: define areas within game
//Author: Rob Wagner
//Date last modified: November 17th, 2017
//-------------------------------------------------------------

//The map class contains 25 locations which are defined using a 
//5x5 2-dimensional array.
//The player can move to each location to find clues or other "nuggets"
    
    //define variables
    private int numRows;
    private int numColumns;
    private Location[][] locations;
    
    //The default constructor
    public Map()
    {}

    //parameterized constructor
    //Purpose: Initialize the Map object
    //Parameters: the number of rows and columns in the map
    //Pre-conditions: parameters must be non-zero and positive
    public Map(int _rows, int _columns)
    {
        numRows = _rows;
        numColumns = _columns;
        
        //create the locations array
        locations = new Location[numRows][numColumns];
        
        //create a set of location objects and store in the locations array
        for(int i = 0; i < numRows; i++)
        {
            for(int j = 0; j < numColumns; j++)
            {
                Location location = new Location();
                location.setRow(i);
                location.setColumn(j);
                //This last line creates constructor for any of the 25 locations.
                locations[i][j] = location;
            }
        }
        
        //Set up the description and symbols for each location
        //the nile river runs through column 4
        String nile = "\nYou are on the River Nile. The river marks the eastern " +
                      "\nboundary of the village - you cannot go any further east." +
                      "\nPlus a crocodile takes a snap at you, time to get back to work";
        for(int i = 0; i < numRows; i++)
        {
            locations[i][4].setDescription(nile);
            locations[i][4].setSymbol("~~~");
        }
        
        // farmland takes up all of column 3
        String farmland = "\nAs you travel through the fertile banks of the River Nile, ";
       
        for(int i = 0; i < numRows; i++)
        {
            for(int j = 3; j < 4; j++)
            {
                locations[i][j].setDescription(farmland);
                locations[i][j].setSymbol("|||");
            }
        }  
        
        //locations with hints
        locations[0][1].setDescription(farmland + "\nyou meet an old wiseman in your travels. He asks you if you have any Kamut, a specialty grain derived from an ancient Egyptian variety of wheat. You tell him 'ain't nobody got time fo' that!', and move on.");
        locations[1][1].setDescription(farmland + "\nyou find a protein bar! Add 3 strength to your task masters as they beat more production out of your slaves.");
        locations[2][1].setDescription(farmland + "\nyou find a curious scrap of paper that reads 'It takes 20 bushels of grain to feed one person per year' ");
        locations[3][1].setDescription(farmland + "\nand a small child working with his dad on the farm yells out to you, 'Did you know one bushel will plant two acres of wheat?'.");
        locations[4][1].setDescription(farmland + "\nyou ask a tired looking man how his day is going, he responds (hint) 'One person can only tend about nine acres of ground'.");
        locations[0][2].setDescription(farmland + "\nyou discover that these are not the droids you're looking for");
        locations[1][2].setDescription(farmland + "\nyou find a cobra, you decide to visit another spot.");
        locations[2][2].setDescription(farmland + "\nyou step on a Scorpion. You say 'ouch'.");
        locations[3][2].setDescription(farmland + "\nand did I mention that one bushel of grain will plant two acres? Well it will.");
        locations[4][2].setDescription(farmland + "\nand uh, not sure if you really have time for vacationing, you got a village to feed man!");
        
        //village descriptions
        String village = "\nYou are in the village. The wheat fields are east of here." +
                         "\nThe desert is to the south. There is no McDonald's, only wheat";
        locations[2][0].setDescription(village);
        locations[3][0].setDescription(village);
        locations[4][0].setDescription(village + "\nYou should go out in the fields and talk to the farmers." +
                                                  "\nThey can give you some good advice on how to manage the crops.");
        
        //village symbols
        locations[2][0].setSymbol("oOo");
        locations[3][0].setSymbol("oOo");
        locations[4][0].setSymbol("oOo");
        
        //desert descriptions
        String desert = "\nYou are in the desert. Not much grows here.";
        for(int i = 0; i < 2; i++)
        {
            for(int j = 0; j <= 0; j++)
            {
                locations[i][j].setDescription(desert);
                locations[i][j].setSymbol("...");
            }
        }
        
    }
    
    public int getNumRows()
    {
        return numRows;
    }
    
    public int getNumColumns()
    {
        return numColumns;
    }
    
    public Location getLocation(int i, int j)
    {
        return locations[i][j];
    }
    
}

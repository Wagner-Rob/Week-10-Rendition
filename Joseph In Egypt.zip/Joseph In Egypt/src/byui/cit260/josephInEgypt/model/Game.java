/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byui.cit260.josephInEgypt.model;

import java.io.Serializable;
import josephInEgypt.control.*;
import byui.cit260.josephInEgypt.model.*;

/**
 *
 * @author cameroncook
 * @co-author Rob Wagner
 */
    public class Game implements Serializable
    {
        //variables
        private Crops theCrops = null;
        private Map theMap = null;
        private static Game theGame = null;
        private boolean done = true;
        
    public Crops getCrops() {
        return theCrops;
    }
    
    public void setCrops(Crops _setCrops)
    {
        theCrops = _setCrops;
    }  
    
    public Game getTheGame() 
    {
        return theGame;
    }

    public static void setTheGame(Game theGame) 
    {
        Game.theGame = theGame;
    }

    /**
     *
     * @param _cropRef
     */
    public void setCrop(Crops _cropRef) 
    {
        theCrops = _cropRef;
    }

    public Map getMap() 
    {
            Map theMap = null;
        return theMap;
    }

    public void setMap(Map theMap) 
    {
        theMap = Map();
    }

    private Map Map() 
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
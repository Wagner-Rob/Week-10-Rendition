/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byui.cit260.josephInEgypt.view;

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author cameroncook
 */
public class StartProgramViewNGTest {
    
    public StartProgramViewNGTest() {
    }

    /**
     * Test of displayBanner method, of class StartProgramView.
     */
    @Test
    public void testDisplayBanner() {
        System.out.println("displayBanner");
        StartProgramView instance = new StartProgramView();
        instance.displayBanner();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayStartProgramView method, of class StartProgramView.
     */
    @Test
    public void testDisplayStartProgramView() {
        System.out.println("displayStartProgramView");
        StartProgramView instance = new StartProgramView();
        instance.displayStartProgramView();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPlayerName method, of class StartProgramView.
     */
    @Test
    public void testGetPlayerName() {
        System.out.println("getPlayerName");
        StartProgramView instance = new StartProgramView();
        String expResult = "";
        String result = instance.getPlayerName();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayNextView method, of class StartProgramView.
     */
    @Test
    public void testDisplayNextView() {
        System.out.println("displayNextView");
        StartProgramView instance = new StartProgramView();
        instance.displayNextView();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
